package com.example.service;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;

public class MyService extends Service {

    public static final String TAG = "MyService";
    //若是沒有宣告AIDL，需要在這裡建立mBinder
    //private MyBinder mBinder = new MyBinder();

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate()");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "onStartCommand()");

        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy()");
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "onBind()");

        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d(TAG, "onUnbind()");

        return super.onUnbind(intent);
    }

    public class MyBinder extends Binder {
        public MyService getService() {
            return MyService.this;
        }
    }

    public void doSomething() {
        Log.d(TAG, "doSomething()");
    }

    final RemoteCallbackList<IMyAidlCallback> mCallbacks =
            new RemoteCallbackList<IMyAidlCallback>();

    private final IMyAidl.Stub mBinder = new IMyAidl.Stub() {
        public void doSomething() {
            Log.d(TAG, "doSomething()");

            final int count = mCallbacks.beginBroadcast();
            Log.d(TAG, "count = " + count);
            for (int i = 0; i < count; i++) {
                try {
                    //clientCallback()實際的內容定義在client端
                    mCallbacks.getBroadcastItem(i).clientCallback(100);
                } catch (RemoteException e) {
                    // The RemoteCallbackList will take care of removing
                    // the dead object for us.
                    e.printStackTrace();
                }
            }
            mCallbacks.finishBroadcast();
        }

        public void registerCallback(IMyAidlCallback cb) {
            Log.d(TAG, "registerCallback()");

            if (cb != null) mCallbacks.register(cb);
        }
        public void unregisterCallback(IMyAidlCallback cb) {
            Log.d(TAG, "unregisterCallback()");

            if (cb != null) mCallbacks.unregister(cb);
        }
    };
}
