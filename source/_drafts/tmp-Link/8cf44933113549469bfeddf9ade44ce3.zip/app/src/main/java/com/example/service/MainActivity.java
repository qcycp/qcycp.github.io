package com.example.service;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View.OnClickListener;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity implements OnClickListener {

    private static final String TAG = "MainActivity";
    private MyService mService = null;
    boolean mIsBound = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button StartServiceBtn = (Button) findViewById(R.id.StartService);
        Button StopServiceBtn = (Button) findViewById(R.id.StopService);
        Button BindServiceBtn = (Button) findViewById(R.id.BindService);
        Button UnbindServiceBtn = (Button) findViewById(R.id.UnbindService);
        Button BindServiceOpBtn = (Button) findViewById(R.id.BindServiceOperation);
        StartServiceBtn.setOnClickListener(this);
        StopServiceBtn.setOnClickListener(this);
        BindServiceBtn.setOnClickListener(this);
        UnbindServiceBtn.setOnClickListener(this);
        BindServiceOpBtn.setOnClickListener(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mIsBound) {
            unbindService(mConnection);
            mIsBound = false;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.StartService:
                // 單純啟動一個service
                Intent startIntent = new Intent(this, MyService.class);
                startService(startIntent);
                break;
            case R.id.StopService:
                Intent stopIntent = new Intent(this, MyService.class);
                stopService(stopIntent);
                break;
            case R.id.BindService:
                // 啟動一個service，Activity可以跟service互相溝通
                Intent bindIntent = new Intent(this, MyService.class);
                bindService(bindIntent, mConnection, BIND_AUTO_CREATE);
                mIsBound = true;
                break;
            case R.id.UnbindService:
                //若沒有綁定service，unbind會出錯
                if (mIsBound) {
                    unbindService(mConnection);
                    mIsBound = false;
                }
                break;
            case R.id.BindServiceOperation:
                    mService.doSomething();
                break;
            default:
                break;
        }
    }

    private ServiceConnection mConnection = new ServiceConnection() {

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.d(TAG, "onServiceDisconnected()");
            mService = null;
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.d(TAG, "onServiceConnected()");

            //service就是onBind回傳的IBinder
            mService = ((MyService.MyBinder)service).getService();
        }
    };
}
